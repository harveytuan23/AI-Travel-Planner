
To run this application:

```
npm start
```